#include <stdio.h>

int main() 
{
    int a[10]; // a is an integer array of size 10
    int mat[2][3]; // mat is an array of (array of integers of size 3) size 2

    int first = mat[0][0], second = mat[0][1], third = mat[0][2];

    return 0;
}
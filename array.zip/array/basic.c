#include <stdio.h>
#include <assert.h>

void print_array(const int array[], size_t size) {
    for (int i = 0; i < size; ++i) {
        printf("%d ", array[i]);
    }
    printf("\n");
}

double get_min(const double array[], size_t size) {
    assert(size > 0);
    double minimum = array[0];

    for (int i = 1; i < size; ++i) {
        if (array[i] < minimum) {
            minimum = array[i];
        }
    }
    return minimum;
}

int main()
{
    int array[10];
    int array1[12] = {};//{1, 3, 5, 7, 9};
    int array2[] = {0, 2, 4, 6, 8};

    // printf("%lu %zu %lu", sizeof array, sizeof array1, sizeof array2);

    // for (int i = 0; i < 10; i++) {
    //     array[i] = i * i;
    // }
    // print_array(array, 10);

    double d_arr[] = {5.0, 7.0, -2.5, 3.9, 1.34, -0.45, 10.01, -5.77, -3.2, 5.0};

    double minimum = get_min(d_arr, sizeof(d_arr)/sizeof(d_arr[0]));

    printf("%.3lf\n", minimum);
    print_array(array1, 12);
    return 0;
}
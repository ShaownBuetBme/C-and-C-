// Fig. 6.8: fig06_08.c
// Displaying a histogram.
#include <stdio.h>
#define SIZE 5

void print_histogram(int arr[], size_t size) {

    printf("%s%13s%17s\n", "Element", "Value", "Histogram");

    // for each element of array n, output a bar of the histogram
    for (size_t i = 0; i < size; ++i)
    {
        printf("%7lu%13d        ", i, arr[i]);

        for (int j = 1; j <= arr[i]; ++j)
        { // print one bar
            printf("%c", '*');
        }
        puts(""); // end a histogram bar with a newline
    }
}

// function main begins program execution
int main(void)
{
    // use initializer list to initialize array n
    int n[SIZE] = {19, 3, 15, 7, 11};

    print_histogram(n, SIZE);
}